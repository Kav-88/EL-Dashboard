# AetherOps Landing Page

A recolored landing page replica built with the custom palette:

- Deep Forest `#083C27`
- Emerald `#168A4D`
- Dark Emerald `#115E3B`
- Magenta `#C21867`
- Soft Magenta `#D63384`
- Warm White `#F6F4EF`
- White `#FFFFFF`
- Charcoal `#202124`

## Usage

Open `index.html` directly in a browser, or enable GitHub Pages on this repo (Settings → Pages → Deploy from branch → `main` / root) to host it live.
